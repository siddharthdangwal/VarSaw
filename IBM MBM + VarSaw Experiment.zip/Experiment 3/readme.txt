Executed VarSaw on three workloads - CH4-AS3, LiH-AS3, H2O-AS3 and H2-AS3 in conjunction with IBM measurement error mitigation techniques.
