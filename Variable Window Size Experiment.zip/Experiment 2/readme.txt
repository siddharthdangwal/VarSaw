Ran varsaw on three workloads with variable window size. The three workloads considered are:

LiH-AS3, H2-AS3, H2O-AS3, and CH4-AS3.
The varsaw window sizes considered are:
2, 3, 4, 5, 6(??)
